package com.example.wiil_food_and_restaurant_listing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
